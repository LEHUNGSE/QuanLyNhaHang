﻿
namespace CK_QLNH
{
    partial class QLBan_UC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxIdBan = new System.Windows.Forms.TextBox();
            this.labelSoBan = new System.Windows.Forms.Label();
            this.textBoxGiaThanh = new System.Windows.Forms.TextBox();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.TextBoxSL = new System.Windows.Forms.TextBox();
            this.TextBoxTenBan = new System.Windows.Forms.TextBox();
            this.dataGridViewQlBan = new System.Windows.Forms.DataGridView();
            this.textBoxTinhTrang = new System.Windows.Forms.TextBox();
            this.buttonTim = new System.Windows.Forms.Button();
            this.buttonThem = new System.Windows.Forms.Button();
            this.buttonHuy = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.ButtonAddStd = new System.Windows.Forms.Button();
            this.ButtonRemove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQlBan)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxIdBan
            // 
            this.textBoxIdBan.BackColor = System.Drawing.Color.White;
            this.textBoxIdBan.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIdBan.ForeColor = System.Drawing.Color.Black;
            this.textBoxIdBan.Location = new System.Drawing.Point(240, 57);
            this.textBoxIdBan.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxIdBan.Multiline = true;
            this.textBoxIdBan.Name = "textBoxIdBan";
            this.textBoxIdBan.Size = new System.Drawing.Size(157, 41);
            this.textBoxIdBan.TabIndex = 98;
            this.textBoxIdBan.Enter += new System.EventHandler(this.textBoxIdBan_Enter);
            this.textBoxIdBan.Leave += new System.EventHandler(this.textBoxIdBan_Leave);
            // 
            // labelSoBan
            // 
            this.labelSoBan.BackColor = System.Drawing.Color.White;
            this.labelSoBan.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoBan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.labelSoBan.Location = new System.Drawing.Point(411, 474);
            this.labelSoBan.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelSoBan.Name = "labelSoBan";
            this.labelSoBan.Size = new System.Drawing.Size(174, 40);
            this.labelSoBan.TabIndex = 94;
            this.labelSoBan.Text = "So Ban An:";
            this.labelSoBan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBoxGiaThanh
            // 
            this.textBoxGiaThanh.BackColor = System.Drawing.Color.White;
            this.textBoxGiaThanh.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGiaThanh.ForeColor = System.Drawing.Color.Black;
            this.textBoxGiaThanh.Location = new System.Drawing.Point(50, 311);
            this.textBoxGiaThanh.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxGiaThanh.Name = "textBoxGiaThanh";
            this.textBoxGiaThanh.Size = new System.Drawing.Size(221, 29);
            this.textBoxGiaThanh.TabIndex = 93;
            this.textBoxGiaThanh.Enter += new System.EventHandler(this.textBoxGiaThanh_Enter);
            this.textBoxGiaThanh.Leave += new System.EventHandler(this.textBoxGiaThanh_Leave);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.BackColor = System.Drawing.Color.White;
            this.textBoxSearch.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSearch.ForeColor = System.Drawing.Color.Black;
            this.textBoxSearch.Location = new System.Drawing.Point(625, 106);
            this.textBoxSearch.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSearch.Multiline = true;
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(237, 41);
            this.textBoxSearch.TabIndex = 91;
            this.textBoxSearch.Enter += new System.EventHandler(this.textBoxSearch_Enter);
            this.textBoxSearch.Leave += new System.EventHandler(this.textBoxSearch_Leave);
            // 
            // TextBoxSL
            // 
            this.TextBoxSL.BackColor = System.Drawing.Color.White;
            this.TextBoxSL.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxSL.ForeColor = System.Drawing.Color.Black;
            this.TextBoxSL.Location = new System.Drawing.Point(50, 235);
            this.TextBoxSL.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxSL.Name = "TextBoxSL";
            this.TextBoxSL.Size = new System.Drawing.Size(221, 29);
            this.TextBoxSL.TabIndex = 89;
            this.TextBoxSL.Enter += new System.EventHandler(this.TextBoxSL_Enter);
            this.TextBoxSL.Leave += new System.EventHandler(this.TextBoxSL_Leave);
            // 
            // TextBoxTenBan
            // 
            this.TextBoxTenBan.BackColor = System.Drawing.Color.White;
            this.TextBoxTenBan.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxTenBan.ForeColor = System.Drawing.Color.Black;
            this.TextBoxTenBan.Location = new System.Drawing.Point(50, 164);
            this.TextBoxTenBan.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxTenBan.Name = "TextBoxTenBan";
            this.TextBoxTenBan.Size = new System.Drawing.Size(221, 29);
            this.TextBoxTenBan.TabIndex = 88;
            this.TextBoxTenBan.Enter += new System.EventHandler(this.TextBoxTenBan_Enter);
            this.TextBoxTenBan.Leave += new System.EventHandler(this.TextBoxTenBan_Leave);
            // 
            // dataGridViewQlBan
            // 
            this.dataGridViewQlBan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewQlBan.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewQlBan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewQlBan.Location = new System.Drawing.Point(415, 164);
            this.dataGridViewQlBan.Name = "dataGridViewQlBan";
            this.dataGridViewQlBan.RowHeadersWidth = 51;
            this.dataGridViewQlBan.RowTemplate.Height = 24;
            this.dataGridViewQlBan.Size = new System.Drawing.Size(887, 286);
            this.dataGridViewQlBan.TabIndex = 81;
            this.dataGridViewQlBan.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewQlBan_CellDoubleClick);
            // 
            // textBoxTinhTrang
            // 
            this.textBoxTinhTrang.BackColor = System.Drawing.Color.White;
            this.textBoxTinhTrang.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTinhTrang.ForeColor = System.Drawing.Color.Black;
            this.textBoxTinhTrang.Location = new System.Drawing.Point(50, 383);
            this.textBoxTinhTrang.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTinhTrang.Name = "textBoxTinhTrang";
            this.textBoxTinhTrang.Size = new System.Drawing.Size(221, 29);
            this.textBoxTinhTrang.TabIndex = 155;
            this.textBoxTinhTrang.Enter += new System.EventHandler(this.textBoxTinhTrang_Enter);
            this.textBoxTinhTrang.Leave += new System.EventHandler(this.textBoxTinhTrang_Leave);
            // 
            // buttonTim
            // 
            this.buttonTim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.buttonTim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonTim.ForeColor = System.Drawing.Color.White;
            this.buttonTim.Image = global::CK_QLNH.Properties.Resources.Search_icon__1_;
            this.buttonTim.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTim.Location = new System.Drawing.Point(415, 106);
            this.buttonTim.Margin = new System.Windows.Forms.Padding(4);
            this.buttonTim.Name = "buttonTim";
            this.buttonTim.Size = new System.Drawing.Size(191, 41);
            this.buttonTim.TabIndex = 99;
            this.buttonTim.Text = "Tìm Kiếm";
            this.buttonTim.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonTim.UseVisualStyleBackColor = false;
            this.buttonTim.Click += new System.EventHandler(this.buttonTim_Click);
            // 
            // buttonThem
            // 
            this.buttonThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.buttonThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonThem.ForeColor = System.Drawing.Color.White;
            this.buttonThem.Image = global::CK_QLNH.Properties.Resources.Add_Folder_icon;
            this.buttonThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonThem.Location = new System.Drawing.Point(415, 57);
            this.buttonThem.Margin = new System.Windows.Forms.Padding(4);
            this.buttonThem.Name = "buttonThem";
            this.buttonThem.Size = new System.Drawing.Size(191, 41);
            this.buttonThem.TabIndex = 96;
            this.buttonThem.Text = "Thêm Bàn Ăn";
            this.buttonThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonThem.UseVisualStyleBackColor = false;
            this.buttonThem.Click += new System.EventHandler(this.buttonThem_Click);
            // 
            // buttonHuy
            // 
            this.buttonHuy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.buttonHuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonHuy.ForeColor = System.Drawing.Color.White;
            this.buttonHuy.Image = global::CK_QLNH.Properties.Resources.Windows_Close_Program_icon;
            this.buttonHuy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHuy.Location = new System.Drawing.Point(625, 57);
            this.buttonHuy.Margin = new System.Windows.Forms.Padding(4);
            this.buttonHuy.Name = "buttonHuy";
            this.buttonHuy.Size = new System.Drawing.Size(237, 41);
            this.buttonHuy.TabIndex = 95;
            this.buttonHuy.Text = "Hủy Thêm Bàn";
            this.buttonHuy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonHuy.UseVisualStyleBackColor = false;
            this.buttonHuy.Click += new System.EventHandler(this.buttonHuy_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.buttonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonEdit.ForeColor = System.Drawing.Color.White;
            this.buttonEdit.Image = global::CK_QLNH.Properties.Resources.pencil_icon;
            this.buttonEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEdit.Location = new System.Drawing.Point(1123, 106);
            this.buttonEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(179, 41);
            this.buttonEdit.TabIndex = 84;
            this.buttonEdit.Text = "Chỉnh Sửa";
            this.buttonEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonEdit.UseVisualStyleBackColor = false;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // ButtonAddStd
            // 
            this.ButtonAddStd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonAddStd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonAddStd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ButtonAddStd.ForeColor = System.Drawing.Color.White;
            this.ButtonAddStd.Image = global::CK_QLNH.Properties.Resources.Save_icon;
            this.ButtonAddStd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonAddStd.Location = new System.Drawing.Point(50, 57);
            this.ButtonAddStd.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonAddStd.Name = "ButtonAddStd";
            this.ButtonAddStd.Size = new System.Drawing.Size(160, 41);
            this.ButtonAddStd.TabIndex = 83;
            this.ButtonAddStd.Text = "Lưu Bàn";
            this.ButtonAddStd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ButtonAddStd.UseVisualStyleBackColor = false;
            this.ButtonAddStd.Click += new System.EventHandler(this.ButtonAddBanAn_Click);
            // 
            // ButtonRemove
            // 
            this.ButtonRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ButtonRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ButtonRemove.ForeColor = System.Drawing.Color.White;
            this.ButtonRemove.Image = global::CK_QLNH.Properties.Resources.delete_file_icon;
            this.ButtonRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonRemove.Location = new System.Drawing.Point(890, 106);
            this.ButtonRemove.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonRemove.Name = "ButtonRemove";
            this.ButtonRemove.Size = new System.Drawing.Size(197, 41);
            this.ButtonRemove.TabIndex = 82;
            this.ButtonRemove.Text = "Xóa Bàn Ăn";
            this.ButtonRemove.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ButtonRemove.UseVisualStyleBackColor = false;
            this.ButtonRemove.Click += new System.EventHandler(this.ButtonRemove_Click);
            // 
            // QLBan_UC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.textBoxTinhTrang);
            this.Controls.Add(this.buttonTim);
            this.Controls.Add(this.textBoxIdBan);
            this.Controls.Add(this.buttonThem);
            this.Controls.Add(this.buttonHuy);
            this.Controls.Add(this.labelSoBan);
            this.Controls.Add(this.textBoxGiaThanh);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.TextBoxSL);
            this.Controls.Add(this.TextBoxTenBan);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.ButtonAddStd);
            this.Controls.Add(this.ButtonRemove);
            this.Controls.Add(this.dataGridViewQlBan);
            this.Name = "QLBan_UC";
            this.Size = new System.Drawing.Size(1380, 633);
            this.Load += new System.EventHandler(this.QLBan_UC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQlBan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxIdBan;
        private System.Windows.Forms.Button buttonThem;
        private System.Windows.Forms.Button buttonHuy;
        private System.Windows.Forms.Label labelSoBan;
        private System.Windows.Forms.TextBox textBoxGiaThanh;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.TextBox TextBoxSL;
        private System.Windows.Forms.TextBox TextBoxTenBan;
        private System.Windows.Forms.Button buttonEdit;
        private System.Windows.Forms.Button ButtonAddStd;
        private System.Windows.Forms.Button ButtonRemove;
        private System.Windows.Forms.DataGridView dataGridViewQlBan;
        private System.Windows.Forms.Button buttonTim;
        private System.Windows.Forms.TextBox textBoxTinhTrang;
    }
}
