﻿
namespace CK_QLNH
{
    partial class QLMon_UC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.textBoxIdMon = new System.Windows.Forms.TextBox();
            this.labelSoMon = new System.Windows.Forms.Label();
            this.TextBoxSL = new System.Windows.Forms.TextBox();
            this.textBoxGiaThanh = new System.Windows.Forms.TextBox();
            this.TextBoxNguyenLieu = new System.Windows.Forms.TextBox();
            this.TextBoxTenMon = new System.Windows.Forms.TextBox();
            this.dataGridViewQlMon = new System.Windows.Forms.DataGridView();
            this.buttonKtraSL = new System.Windows.Forms.Button();
            this.buttonTim = new System.Windows.Forms.Button();
            this.buttonThem = new System.Windows.Forms.Button();
            this.buttonHuy = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.ButtonLuu = new System.Windows.Forms.Button();
            this.ButtonRemove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQlMon)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.BackColor = System.Drawing.Color.White;
            this.textBoxSearch.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSearch.ForeColor = System.Drawing.Color.Black;
            this.textBoxSearch.Location = new System.Drawing.Point(609, 105);
            this.textBoxSearch.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSearch.Multiline = true;
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(219, 40);
            this.textBoxSearch.TabIndex = 103;
            this.textBoxSearch.Enter += new System.EventHandler(this.textBoxSearch_Enter);
            this.textBoxSearch.Leave += new System.EventHandler(this.textBoxSearch_Leave);
            // 
            // textBoxIdMon
            // 
            this.textBoxIdMon.BackColor = System.Drawing.Color.White;
            this.textBoxIdMon.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIdMon.ForeColor = System.Drawing.Color.Black;
            this.textBoxIdMon.Location = new System.Drawing.Point(270, 53);
            this.textBoxIdMon.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxIdMon.Multiline = true;
            this.textBoxIdMon.Name = "textBoxIdMon";
            this.textBoxIdMon.Size = new System.Drawing.Size(138, 41);
            this.textBoxIdMon.TabIndex = 118;
            this.textBoxIdMon.Enter += new System.EventHandler(this.textBoxIdMon_Enter);
            this.textBoxIdMon.Leave += new System.EventHandler(this.textBoxIdMon_Leave);
            // 
            // labelSoMon
            // 
            this.labelSoMon.BackColor = System.Drawing.Color.White;
            this.labelSoMon.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSoMon.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.labelSoMon.Location = new System.Drawing.Point(411, 572);
            this.labelSoMon.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.labelSoMon.Name = "labelSoMon";
            this.labelSoMon.Size = new System.Drawing.Size(174, 39);
            this.labelSoMon.TabIndex = 116;
            this.labelSoMon.Text = "So Mon An:";
            this.labelSoMon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // TextBoxSL
            // 
            this.TextBoxSL.BackColor = System.Drawing.Color.White;
            this.TextBoxSL.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxSL.ForeColor = System.Drawing.Color.Black;
            this.TextBoxSL.Location = new System.Drawing.Point(62, 374);
            this.TextBoxSL.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxSL.Name = "TextBoxSL";
            this.TextBoxSL.Size = new System.Drawing.Size(218, 29);
            this.TextBoxSL.TabIndex = 115;
            this.TextBoxSL.Enter += new System.EventHandler(this.TextBoxSL_Enter);
            this.TextBoxSL.Leave += new System.EventHandler(this.TextBoxSL_Leave);
            // 
            // textBoxGiaThanh
            // 
            this.textBoxGiaThanh.BackColor = System.Drawing.Color.White;
            this.textBoxGiaThanh.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGiaThanh.ForeColor = System.Drawing.Color.Black;
            this.textBoxGiaThanh.Location = new System.Drawing.Point(62, 236);
            this.textBoxGiaThanh.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxGiaThanh.Name = "textBoxGiaThanh";
            this.textBoxGiaThanh.Size = new System.Drawing.Size(218, 29);
            this.textBoxGiaThanh.TabIndex = 113;
            this.textBoxGiaThanh.Enter += new System.EventHandler(this.textBoxGiaThanh_Enter);
            this.textBoxGiaThanh.Leave += new System.EventHandler(this.textBoxGiaThanh_Leave);
            // 
            // TextBoxNguyenLieu
            // 
            this.TextBoxNguyenLieu.BackColor = System.Drawing.Color.White;
            this.TextBoxNguyenLieu.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxNguyenLieu.ForeColor = System.Drawing.Color.Black;
            this.TextBoxNguyenLieu.Location = new System.Drawing.Point(62, 304);
            this.TextBoxNguyenLieu.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxNguyenLieu.Name = "TextBoxNguyenLieu";
            this.TextBoxNguyenLieu.Size = new System.Drawing.Size(218, 29);
            this.TextBoxNguyenLieu.TabIndex = 111;
            this.TextBoxNguyenLieu.Enter += new System.EventHandler(this.TextBoxNguyenLieu_Enter);
            this.TextBoxNguyenLieu.Leave += new System.EventHandler(this.TextBoxNguyenLieu_Leave);
            // 
            // TextBoxTenMon
            // 
            this.TextBoxTenMon.BackColor = System.Drawing.Color.White;
            this.TextBoxTenMon.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxTenMon.ForeColor = System.Drawing.Color.Black;
            this.TextBoxTenMon.Location = new System.Drawing.Point(62, 166);
            this.TextBoxTenMon.Margin = new System.Windows.Forms.Padding(4);
            this.TextBoxTenMon.Name = "TextBoxTenMon";
            this.TextBoxTenMon.Size = new System.Drawing.Size(218, 29);
            this.TextBoxTenMon.TabIndex = 110;
            this.TextBoxTenMon.Enter += new System.EventHandler(this.TextBoxTenMon_Enter);
            this.TextBoxTenMon.Leave += new System.EventHandler(this.TextBoxTenMon_Leave);
            // 
            // dataGridViewQlMon
            // 
            this.dataGridViewQlMon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewQlMon.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewQlMon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewQlMon.Location = new System.Drawing.Point(416, 166);
            this.dataGridViewQlMon.Name = "dataGridViewQlMon";
            this.dataGridViewQlMon.RowHeadersWidth = 51;
            this.dataGridViewQlMon.RowTemplate.Height = 24;
            this.dataGridViewQlMon.Size = new System.Drawing.Size(876, 374);
            this.dataGridViewQlMon.TabIndex = 107;
            this.dataGridViewQlMon.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewQlMon_CellDoubleClick);
            // 
            // buttonKtraSL
            // 
            this.buttonKtraSL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.buttonKtraSL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKtraSL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonKtraSL.ForeColor = System.Drawing.Color.White;
            this.buttonKtraSL.Image = global::CK_QLNH.Properties.Resources.list_icon;
            this.buttonKtraSL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonKtraSL.Location = new System.Drawing.Point(62, 499);
            this.buttonKtraSL.Margin = new System.Windows.Forms.Padding(4);
            this.buttonKtraSL.Name = "buttonKtraSL";
            this.buttonKtraSL.Size = new System.Drawing.Size(218, 41);
            this.buttonKtraSL.TabIndex = 160;
            this.buttonKtraSL.Text = "Kiểm Tra SL";
            this.buttonKtraSL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonKtraSL.UseVisualStyleBackColor = false;
            this.buttonKtraSL.Click += new System.EventHandler(this.buttonKtraSL_Click);
            // 
            // buttonTim
            // 
            this.buttonTim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.buttonTim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonTim.ForeColor = System.Drawing.Color.White;
            this.buttonTim.Image = global::CK_QLNH.Properties.Resources.Search_icon__1_;
            this.buttonTim.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTim.Location = new System.Drawing.Point(416, 104);
            this.buttonTim.Margin = new System.Windows.Forms.Padding(4);
            this.buttonTim.Name = "buttonTim";
            this.buttonTim.Size = new System.Drawing.Size(173, 41);
            this.buttonTim.TabIndex = 106;
            this.buttonTim.Text = "Tìm Kiếm";
            this.buttonTim.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonTim.UseVisualStyleBackColor = false;
            this.buttonTim.Click += new System.EventHandler(this.buttonTim_Click);
            // 
            // buttonThem
            // 
            this.buttonThem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.buttonThem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonThem.ForeColor = System.Drawing.Color.White;
            this.buttonThem.Image = global::CK_QLNH.Properties.Resources.Add_Folder_icon;
            this.buttonThem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonThem.Location = new System.Drawing.Point(416, 53);
            this.buttonThem.Margin = new System.Windows.Forms.Padding(4);
            this.buttonThem.Name = "buttonThem";
            this.buttonThem.Size = new System.Drawing.Size(173, 41);
            this.buttonThem.TabIndex = 105;
            this.buttonThem.Text = "Thêm Món";
            this.buttonThem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonThem.UseVisualStyleBackColor = false;
            this.buttonThem.Click += new System.EventHandler(this.buttonThem_Click);
            // 
            // buttonHuy
            // 
            this.buttonHuy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.buttonHuy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHuy.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonHuy.ForeColor = System.Drawing.Color.White;
            this.buttonHuy.Image = global::CK_QLNH.Properties.Resources.Windows_Close_Program_icon;
            this.buttonHuy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHuy.Location = new System.Drawing.Point(609, 53);
            this.buttonHuy.Margin = new System.Windows.Forms.Padding(4);
            this.buttonHuy.Name = "buttonHuy";
            this.buttonHuy.Size = new System.Drawing.Size(219, 41);
            this.buttonHuy.TabIndex = 104;
            this.buttonHuy.Text = "Hủy Thêm Món";
            this.buttonHuy.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonHuy.UseVisualStyleBackColor = false;
            this.buttonHuy.Click += new System.EventHandler(this.buttonHuy_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.buttonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.buttonEdit.ForeColor = System.Drawing.Color.White;
            this.buttonEdit.Image = global::CK_QLNH.Properties.Resources.pencil_icon;
            this.buttonEdit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEdit.Location = new System.Drawing.Point(1098, 105);
            this.buttonEdit.Margin = new System.Windows.Forms.Padding(4);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(194, 41);
            this.buttonEdit.TabIndex = 102;
            this.buttonEdit.Text = "Chỉnh Sửa";
            this.buttonEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonEdit.UseVisualStyleBackColor = false;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // ButtonLuu
            // 
            this.ButtonLuu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.ButtonLuu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonLuu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ButtonLuu.ForeColor = System.Drawing.Color.White;
            this.ButtonLuu.Image = global::CK_QLNH.Properties.Resources.Save_icon;
            this.ButtonLuu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonLuu.Location = new System.Drawing.Point(62, 53);
            this.ButtonLuu.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonLuu.Name = "ButtonLuu";
            this.ButtonLuu.Size = new System.Drawing.Size(197, 41);
            this.ButtonLuu.TabIndex = 101;
            this.ButtonLuu.Text = "Lưu Thực Đơn";
            this.ButtonLuu.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ButtonLuu.UseVisualStyleBackColor = false;
            this.ButtonLuu.Click += new System.EventHandler(this.ButtonLuu_Click);
            // 
            // ButtonRemove
            // 
            this.ButtonRemove.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(153)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.ButtonRemove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButtonRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.ButtonRemove.ForeColor = System.Drawing.Color.White;
            this.ButtonRemove.Image = global::CK_QLNH.Properties.Resources.delete_file_icon;
            this.ButtonRemove.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButtonRemove.Location = new System.Drawing.Point(859, 105);
            this.ButtonRemove.Margin = new System.Windows.Forms.Padding(4);
            this.ButtonRemove.Name = "ButtonRemove";
            this.ButtonRemove.Size = new System.Drawing.Size(211, 41);
            this.ButtonRemove.TabIndex = 100;
            this.ButtonRemove.Text = "Xóa Món Ăn";
            this.ButtonRemove.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ButtonRemove.UseVisualStyleBackColor = false;
            this.ButtonRemove.Click += new System.EventHandler(this.ButtonRemove_Click);
            // 
            // QLMon_UC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.buttonKtraSL);
            this.Controls.Add(this.textBoxIdMon);
            this.Controls.Add(this.labelSoMon);
            this.Controls.Add(this.TextBoxSL);
            this.Controls.Add(this.textBoxGiaThanh);
            this.Controls.Add(this.TextBoxNguyenLieu);
            this.Controls.Add(this.TextBoxTenMon);
            this.Controls.Add(this.dataGridViewQlMon);
            this.Controls.Add(this.buttonTim);
            this.Controls.Add(this.buttonThem);
            this.Controls.Add(this.buttonHuy);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.ButtonLuu);
            this.Controls.Add(this.ButtonRemove);
            this.Name = "QLMon_UC";
            this.Size = new System.Drawing.Size(1395, 656);
            this.Load += new System.EventHandler(this.QLMon_UC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewQlMon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonTim;
        private System.Windows.Forms.Button buttonThem;
        private System.Windows.Forms.Button buttonHuy;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonEdit;
        private System.Windows.Forms.Button ButtonLuu;
        private System.Windows.Forms.Button ButtonRemove;
        private System.Windows.Forms.TextBox textBoxIdMon;
        private System.Windows.Forms.Label labelSoMon;
        private System.Windows.Forms.TextBox TextBoxSL;
        private System.Windows.Forms.TextBox textBoxGiaThanh;
        private System.Windows.Forms.TextBox TextBoxNguyenLieu;
        private System.Windows.Forms.TextBox TextBoxTenMon;
        private System.Windows.Forms.DataGridView dataGridViewQlMon;
        private System.Windows.Forms.Button buttonKtraSL;
    }
}
