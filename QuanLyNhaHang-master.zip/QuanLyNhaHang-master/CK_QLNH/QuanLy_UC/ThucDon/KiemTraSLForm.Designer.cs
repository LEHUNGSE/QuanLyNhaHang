﻿
namespace CK_QLNH
{
    partial class KiemTraSLForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxTinhBot = new System.Windows.Forms.TextBox();
            this.textBoxThit = new System.Windows.Forms.TextBox();
            this.textBoxRau = new System.Windows.Forms.TextBox();
            this.comboBoxTenMon = new System.Windows.Forms.ComboBox();
            this.buttonKtraSL = new System.Windows.Forms.Button();
            this.labelKtra = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelCongThuc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxTinhBot
            // 
            this.textBoxTinhBot.BackColor = System.Drawing.Color.White;
            this.textBoxTinhBot.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTinhBot.ForeColor = System.Drawing.Color.Black;
            this.textBoxTinhBot.Location = new System.Drawing.Point(56, 158);
            this.textBoxTinhBot.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTinhBot.Name = "textBoxTinhBot";
            this.textBoxTinhBot.Size = new System.Drawing.Size(164, 29);
            this.textBoxTinhBot.TabIndex = 162;
            // 
            // textBoxThit
            // 
            this.textBoxThit.BackColor = System.Drawing.Color.White;
            this.textBoxThit.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxThit.ForeColor = System.Drawing.Color.Black;
            this.textBoxThit.Location = new System.Drawing.Point(56, 41);
            this.textBoxThit.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxThit.Name = "textBoxThit";
            this.textBoxThit.Size = new System.Drawing.Size(164, 29);
            this.textBoxThit.TabIndex = 161;
            // 
            // textBoxRau
            // 
            this.textBoxRau.BackColor = System.Drawing.Color.White;
            this.textBoxRau.Font = new System.Drawing.Font("Microsoft JhengHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxRau.ForeColor = System.Drawing.Color.Black;
            this.textBoxRau.Location = new System.Drawing.Point(56, 101);
            this.textBoxRau.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRau.Name = "textBoxRau";
            this.textBoxRau.Size = new System.Drawing.Size(164, 29);
            this.textBoxRau.TabIndex = 160;
            // 
            // comboBoxTenMon
            // 
            this.comboBoxTenMon.FormattingEnabled = true;
            this.comboBoxTenMon.Location = new System.Drawing.Point(56, 230);
            this.comboBoxTenMon.Name = "comboBoxTenMon";
            this.comboBoxTenMon.Size = new System.Drawing.Size(121, 24);
            this.comboBoxTenMon.TabIndex = 163;
            this.comboBoxTenMon.SelectedValueChanged += new System.EventHandler(this.comboBoxTenMon_SelectedValueChanged);
            // 
            // buttonKtraSL
            // 
            this.buttonKtraSL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.buttonKtraSL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonKtraSL.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.buttonKtraSL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.buttonKtraSL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonKtraSL.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonKtraSL.ForeColor = System.Drawing.Color.White;
            this.buttonKtraSL.Image = global::CK_QLNH.Properties.Resources.Add_Folder_icon;
            this.buttonKtraSL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonKtraSL.Location = new System.Drawing.Point(56, 292);
            this.buttonKtraSL.Margin = new System.Windows.Forms.Padding(4);
            this.buttonKtraSL.Name = "buttonKtraSL";
            this.buttonKtraSL.Size = new System.Drawing.Size(164, 33);
            this.buttonKtraSL.TabIndex = 164;
            this.buttonKtraSL.Text = "Kiểm Tra SL";
            this.buttonKtraSL.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttonKtraSL.UseVisualStyleBackColor = false;
            this.buttonKtraSL.Click += new System.EventHandler(this.buttonKtraSL_Click);
            // 
            // labelKtra
            // 
            this.labelKtra.AutoSize = true;
            this.labelKtra.Font = new System.Drawing.Font("Microsoft YaHei", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelKtra.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.labelKtra.Location = new System.Drawing.Point(263, 302);
            this.labelKtra.Name = "labelKtra";
            this.labelKtra.Size = new System.Drawing.Size(0, 23);
            this.labelKtra.TabIndex = 165;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(261, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 166;
            this.label1.Text = "Tinh Bột";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(261, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 20);
            this.label2.TabIndex = 167;
            this.label2.Text = "Rau ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(261, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 20);
            this.label3.TabIndex = 168;
            this.label3.Text = "Thịt";
            // 
            // labelCongThuc
            // 
            this.labelCongThuc.AutoSize = true;
            this.labelCongThuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCongThuc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.labelCongThuc.Location = new System.Drawing.Point(264, 237);
            this.labelCongThuc.Name = "labelCongThuc";
            this.labelCongThuc.Size = new System.Drawing.Size(0, 20);
            this.labelCongThuc.TabIndex = 169;
            // 
            // KiemTraSLForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(873, 431);
            this.Controls.Add(this.labelCongThuc);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelKtra);
            this.Controls.Add(this.buttonKtraSL);
            this.Controls.Add(this.comboBoxTenMon);
            this.Controls.Add(this.textBoxTinhBot);
            this.Controls.Add(this.textBoxThit);
            this.Controls.Add(this.textBoxRau);
            this.Name = "KiemTraSLForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KiemTraSLForm";
            this.Load += new System.EventHandler(this.KiemTraSLForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxTinhBot;
        private System.Windows.Forms.TextBox textBoxThit;
        private System.Windows.Forms.TextBox textBoxRau;
        private System.Windows.Forms.ComboBox comboBoxTenMon;
        private System.Windows.Forms.Button buttonKtraSL;
        private System.Windows.Forms.Label labelKtra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelCongThuc;
    }
}