# QuanLyNhaHang
Final project of Windows Programming ( Project Cuối kỳ môn Lập trình Windown )

• Programming language : C#

• Integrated development environment (IDE) : Visual Studio 2019

• Relational database management system : SQL Server

• Author : Nguyen Thai Hai - Tran Luu The Anh

* Link video demo: https://youtu.be/aHj5MPPLi_A

